<div class="container bg-light shadow">
<h1 class="text-center">PROMOCIONES</h1>
</div>