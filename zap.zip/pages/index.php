<?php
    if (isset($_REQUEST['mensaje'])) {
        echo "Bienvenido : " .$_REQUEST['mensaje'];
    }