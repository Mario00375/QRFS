<div class="container bg-light shadow">
<?php
  /* listado; insertar, editar, eliminar */
    $action = "listado";
    if (isset($_REQUEST['action']))
        $action = $_REQUEST['action'];
    switch ($action) {
        case 'listado':
            ?>
            <h1 class="shadow text-black">PRODUCTOS</h1>
            <a href="?pagina=productos&action=insertar" class="btn btn-danger">CREAR</a>
            <table class="table">
                <thead><th>ID</th><th>NOMBRE</th><th>QR</th><th>ACCIONES</th></thead>
                <tbody>
                    <?php 
                        $u=$user->buscar("products","1");
                        foreach($u as $r):
                    ?>
                        <tr>
                            <td><?php  echo $r['ID'];  ?></td>
                            <td><?php  echo $r['Name'];  ?></td>
                            <td><img src="img/qr/<?php  echo $r['Qr'];  ?>"></td>
                            <td>
                                <a href="?pagina=productos&action=editar&id=<?php echo $r['ID']; ?>" class="btn btn-primary">EDITAR</a>
                                <a href="?pagina=productos&action=eliminar" class="btn btn-danger">ELIMINAR</a>
                            </td>
                        </tr>

                    <?php   
                        endforeach;
                    ?>
                </tbody>
            </table>
            <?php
            break;
        case 'insertar':
            if(isset($_POST['btn'])):
                $nombre = $_POST['nombre'];
                $descripcion = $_POST['descripcion'];
                $precio = $_POST['precio'];
                $stok = $_POST['stok'];
                $estado = $_POST['estado'];
                //subir imagen a servidor
                $foto = $_FILES['foto']['name'];
                if(move_uploaded_file($_FILES['foto']['tmp_name'],"img/".$foto))
                    echo "foto subida";
                else
                    echo "Error al subir foto";

                //generar qr
                $qr = "foto.png";
                $data = "'".$nombre."','".$descripcion."','".$foto."','".$qr."',".$precio.",".$stok.",".$estado;

                $u = $user->insert("products",$data);

                if($u):
                    require "class/phpqrcode/qrlib.php";
                    $id = $user->lastInsertId();
                    QRcode::png($id,"img/qr/qr_".$id.".png",'L',10,5);
                    $user->actualizar("products","qr='qr_".$id.".png'", "id=".$id);
                    echo "Insercion ok";
                else:
                    echo "Error de insercion";
                endif;
            else:
            ?>
            <div class="col-sm-8">
            <form action="" enctype="multipart/form-data" method="post">
                <div class="form-group">
                    <label for="nombre">NOMBRE:</label>
                    <input type="text" class="form-control" required name="nombre">
                </div>
                <div class="form-group">
                    <label for="description">DESCRIPCION:</label>
                    <textarea class="form-control" required name="descripcion"></textarea>
                </div>
                <div class="form-group">
                    <label for="foto">FOTO:</label>
                    <input type="file" class="form-control" required name="foto">
                </div>
                    <div class="form-group">
                    <label for="precio">PRECIO:</label>
                    <input type="text" class="form-control" required name="precio">
                </div>
                    <div class="form-group">
                    <label for="stok">STOK:</label>
                    <input type="text" class="form-control" required name="stok">
                </div>
                    <div class="form-group">
                    <label for="estado">ESTADO:</label>
                    <input type="text" class="form-control" required name="estado">
                </div>
                <input type="submit" name="btn" value="ENVIAR" class="btn btn-success">
            </form>
            </div>
            <?php
            endif;
            break;
        case 'editar':
            if(isset($_POST['btn'])):
                $nombre = $_POST['nombre'];
                $descripcion = $_POST['descripcion'];
                $precio = $_POST['precio'];
                $stok = $_POST['stok'];
                $estado = $_POST['estado'];
                //subir imagen a servidor
                
                $foto = $_FILES['foto']['name'];
                if(move_uploaded_file($_FILES['foto']['tmp_name'],"img/".$foto))
                    echo "foto subida";
                else
                    echo "Error al subir foto";
                
                //generar qr
                $qr = "foto.png";

                $data = "Name='".$nombre."',Description='".$descripcion."',Phoro='".$foto."',Price=".$precio.",Stock=".$stok.",State=".$estado;

                $u = $user->actualizar("products",$data,"ID=".$_REQUEST['id']);

                if($u):

                    require "class/phpqrcode/qrlib.php";
                    $id = $_REQUEST['id'];
                    QRcode::png($id,"img/qr/qr_".$id.".png",'L',10,5);
                    $user->actualizar("products","qr='qr_".$id.".png'", "id=".$id);

                    echo "Actualizacion ok";
                else:
                    echo "Error de Actualizacion";
                endif;
            else:
                $u = $user->buscar("products","ID=".$_REQUEST['id']);
                foreach($u as $r):
            ?>
            <div class="col-sm-8">
            <form action="" enctype="multipart/form-data" method="post">
                <div class="form-group">
                    <label for="nombre">NOMBRE:</label>
                    <input type="text" class="form-control" required name="nombre" value="<?php echo $r['Name']?>">
                </div>
                <div class="form-group">
                    <label for="description">DESCRIPCION:</label>
                    <textarea class="form-control" required name="descripcion"><?php echo $r['Description']?></textarea>
                </div>
                <div class="form-group">
                    <label for="foto">FOTO:</label>
                    <img src="img/<?php echo $r['Phoro']?>">
                    <input type="file" class="form-control" name="foto">
                </div>
                    <div class="form-group">
                    <label for="precio">PRECIO:</label>
                    <input type="text" class="form-control" required name="precio" value="<?php echo $r['Price']?>">
                </div>
                    <div class="form-group">
                    <label for="stok">STOK:</label>
                    <input type="text" class="form-control" required name="stok" value="<?php echo $r['Stock']?>">
                </div>
                    <div class="form-group">
                    <label for="estado">ESTADO:</label>
                    <input type="text" class="form-control" required name="estado" value="<?php echo $r['State']?>">
                </div>
                <input type="submit" name="btn" value="ACTUALIZAR" class="btn btn-success">
                <input type="hidden" name="id" value="<?php echo $_REQUEST['id']?>">
            </form>
            </div>
            <?php
            endforeach;
            endif;
            break;
        case 'eliminar':
            echo "eliminar";
            break; 
    }


?>

</div>