<form action="proces/login.php" method="post">
<input type="email" name="txtemail" require placeholder="Correo">
<input type="password" name="txtpassword" require placeholder="Password">
<input type="submit" name="btnlogin" value="Acceder">
</form>