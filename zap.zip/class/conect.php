<?php
class ApptivaDB{
private $host ="127.0.0.1";
private $user = "root";
private $pass = "";
private $db = "qrs";
public $conection;

public function __construct(){
    $this->conect = new mysqli($this->host, $this->user, $this->pass, $this->db) 
    or die(mysqli_error());
    $this->conect->set_charset("utf8");
} 

//INSERT
public function insert($tabla, $datos){
    $result = $this->conect->query("INSERT INTO $tabla VALUES (null,$datos)") or die($this->conect->error);
    if ($result)
        return true;
    return false;
}

//BORRAR
public  function borrar($tabla, $condicion){
    $result = $this->conect->query("DELETE FROM $tabla WHERE $condicion") or die($this->conect->error);
    if ($result)
        return true;
    return false;
}

//ACTUALIZAR
public function actualizar($tabla, $campo, $condicion){
    $result = $this->conect->query("UPDATE $tabla SET $campos WHERE $condicion") or die($this->conect->error);
    if($result)
        return true;
    return false;
}

//buscar 
public function buscar($tabla, $condidion){
    $result = $this->conect->query("SELECT * FROM $tabla WHERE $condicion") or die($this->conect->error);
    if($result)
        return $result->fetch_all(MYSQLI_ASSOC);
    return false;
}

}

?>