<?php
class ApptivaDB{
private $host ="localhost";
private $user = "root";
private $pass = "";
private $db = "qrs";
public $conection;

public function __construct(){
    $this->conexion = new mysqli($this->host, $this->user, $this->pass, $this->db) 
    or die(mysqli_error());
    $this->conexion->set_charset("utf8");
} 

//INSERT
public function insert($tabla, $datos){
    $result = $this->conexion->query("INSERT INTO $tabla VALUES (null,$datos)") or die($this->conexion->error);
    if ($result)
        return true;
    return false;
}

//BORRAR
public  function borrar($tabla, $condicion){
    $result = $this->conexion->query("DELETE FROM $tabla WHERE $condicion") or die($this->conexion->error);
    if ($result)
        return true;
    return false;
}

//ACTUALIZAR
public function actualizar($tabla, $campo, $condicion){
    $result = $this->conexion->query("UPDATE $tabla SET $campo WHERE $condicion") or die($this->conexion->error);
    if($result)
        return true;
    return false;
}

//buscar 
public function buscar($tabla, $condicion){
    $result = $this->conexion->query("SELECT * FROM $tabla WHERE $condicion") or die($this->conexion->error);
    if($result)
        return $result->fetch_all(MYSQLI_ASSOC);
    return false;
}

public function lastInsertId(){
    return $this->conexion->insert_id;
}

}

?>