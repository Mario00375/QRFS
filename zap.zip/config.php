<?php
define("urlsite","http://localhost/qr/")
?>
