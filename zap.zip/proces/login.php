<?php
session_start();
require "../config.php";
$msg = "No se pudo acceder";
if($_POST['btnlogin'] = "Acceder"):
    require "../class/conexion.php";
    $user = new ApptivaDB();

    $email = $_POST['txtemail'];
    $password = md5($_POST['txtpassword']);

    $data = "Email='".$email."'AND Password='".$password."'";
    $u = $user->buscar('users',$data);
    if(!empty($u)):
        foreach($u as $data):
            $_SESSION['admin'] = $data['ID'];
            $msg = $data['Email'];
        endforeach;
    endif;
endif;
header("location:".urlsite."?mensaje=".$msg);

